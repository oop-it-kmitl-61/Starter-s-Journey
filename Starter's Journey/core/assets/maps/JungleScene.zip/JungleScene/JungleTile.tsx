<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="JungleTile" tilewidth="15" tileheight="15" tilecount="820" columns="41">
 <image source="Jungle Asset Pack/jungle tileset/jungle tileset.png" width="624" height="304"/>
</tileset>

<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="car" tilewidth="15" tileheight="15" tilecount="9" columns="3">
 <image source="../keep/opp2_sprites/sprites/misc/spr_obj_cart_str_complete_anim.gif" width="48" height="48"/>
</tileset>

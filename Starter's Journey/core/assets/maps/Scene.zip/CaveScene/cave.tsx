<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="tiles" tilewidth="15" tileheight="15" tilecount="646" columns="34">
 <image source="../keep/caverns-files-web/layers/tiles.png" width="512" height="288"/>
</tileset>

<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="holeBG" tilewidth="15" tileheight="15" tilecount="2584" columns="68">
 <image source="../keep/caverns-files-web/bg2.png" width="1032" height="576"/>
</tileset>

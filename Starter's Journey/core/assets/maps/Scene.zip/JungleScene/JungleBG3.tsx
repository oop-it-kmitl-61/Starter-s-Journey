<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="JungleBG3" tilewidth="15" tileheight="15" tilecount="1428" columns="51">
 <image source="../keep/Jungle Asset Pack/BG2.png" width="768" height="432"/>
</tileset>

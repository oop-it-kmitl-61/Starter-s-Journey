<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="jungle tileset" tilewidth="32" tileheight="32" tilecount="171" columns="19">
 <image source="../keep/Jungle Asset Pack/jungle tileset/jungle tileset.png" width="624" height="304"/>
</tileset>
